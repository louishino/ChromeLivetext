console.log('Content script loaded!');

function createOverlay(img) {
  const overlay = document.createElement('div');
  overlay.className = 'ocr-overlay';
  overlay.style.width = img.width + 'px';
  overlay.style.height = img.height + 'px';
  
  const container = document.createElement('div');
  container.style.position = 'relative';
  container.style.display = 'inline-block';
  
  img.parentNode.insertBefore(container, img);
  container.appendChild(img);
  container.appendChild(overlay);
  
  return overlay;
}

function fetchImageAsBlob(url) {
  return fetch(url, {
    mode: 'cors',
    credentials: 'omit'
  })
    .then(response => {
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      return response.blob();
    })
    .then(blob => createImageBitmap(blob))
    .then(bitmap => {
      const canvas = document.createElement('canvas');
      canvas.width = bitmap.width;
      canvas.height = bitmap.height;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(bitmap, 0, 0);
      return canvas.toDataURL('image/png');
    });
}

function calculateTextStyle(text, bbox, img) {
  const width = bbox[2] * img.width;
  const height = bbox[3] * img.height;
  const fontSize = Math.floor(height * 0.8);
  
  return {
    fontSize: `${fontSize}px`,
    lineHeight: `${height}px`,
    transform: 'none',
    transformOrigin: 'left top'
  };
}

function processImage(img) {
  console.log('开始处理图片:', img.src);
  
  if (!img.complete) {
    console.log('图片未加载完成，等待加载...');
    img.addEventListener('load', () => processImage(img));
    return;
  }

  try {
    fetchImageAsBlob(img.src)
      .then(base64Image => {
        console.log('图片转换为base64完成');
        console.log('发送OCR请求到服务器...');
        
        return fetch('http://localhost:5001/ocr', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
          },
          mode: 'cors',
          body: JSON.stringify({image: base64Image})
        });
      })
      .then(response => {
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        console.log('收到服务器响应:', response.status);
        return response.json();
      })
      .then(data => {
        console.log('OCR结果:', data);
        if (data.success) {
          const overlay = createOverlay(img);
          
          data.annotations.forEach(([text, confidence, bbox]) => {
            if (confidence > 0.3) {
              console.log(`添加文本框: ${text} (置信度: ${confidence})`);
              const textElement = document.createElement('div');
              textElement.className = 'ocr-text';
              textElement.textContent = text;
              
              const x = bbox[0] * 100;
              const y = (1 - bbox[1] - bbox[3]) * 100;
              
              textElement.style.position = 'absolute';
              textElement.style.left = `${x}%`;
              textElement.style.top = `${y}%`;
              textElement.style.width = `${bbox[2] * 100}%`;
              textElement.style.height = `${bbox[3] * 100}%`;
              
              const textStyle = calculateTextStyle(text, bbox, img);
              textElement.style.fontSize = textStyle.fontSize;
              textElement.style.lineHeight = textStyle.lineHeight;
              textElement.style.transform = textStyle.transform;
              textElement.style.transformOrigin = textStyle.transformOrigin;
              
              textElement.title = `文本: ${text}\n置信度: ${(confidence * 100).toFixed(1)}%\n坐标: (${x.toFixed(1)}%, ${y.toFixed(1)}%)`;
              
              overlay.appendChild(textElement);
            }
          });
          
          console.log('OCR overlay添加完成');
        }
      })
      .catch(error => {
        console.error('处理错误:', error);
        if (error.message.includes('Failed to fetch')) {
          console.log('确保Python服务器正在运行在 http://localhost:5001');
        }
      });
  } catch (error) {
    console.error('图片处理错误:', error);
  }
}

// 立即处理当前页面上的图片
console.log('开始扫描页面上的图片...');
const images = document.getElementsByTagName('img');
for (let img of images) {
  processImage(img);
}

// 监听DOM变化，处理新添加的图片
const observer = new MutationObserver(mutations => {
  mutations.forEach(mutation => {
    mutation.addedNodes.forEach(node => {
      if (node.nodeName === 'IMG') {
        processImage(node);
      }
    });
  });
});

observer.observe(document.body, {
  childList: true,
  subtree: true
}); 