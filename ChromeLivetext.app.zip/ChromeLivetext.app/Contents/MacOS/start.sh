#!/bin/bash

# 设置工作目录为应用程序目录
cd "$(dirname "$0")/../Resources"

# 设置环境变量
export FLASK_APP=server.py
export FLASK_ENV=development
export FLASK_DEBUG=1

# 激活Python虚拟环境
source venv/bin/activate

# 确保之前的服务器进程已经关闭
pkill -f "python.*flask.*run" || true

# 等待端口释放
sleep 2

# 启动OCR服务器（添加日志输出）
python -m flask run --host 0.0.0.0 --port 5001 > server.log 2>&1 &

# 等待服务器启动
sleep 3

# 检查服务器是否成功启动
if ! curl -s http://localhost:5001 > /dev/null; then
    osascript -e 'display notification "OCR服务器启动失败，请检查server.log" with title "Safari OCR Clone"'
    exit 1
fi

# 打开Chrome并导航到扩展页面
open -a "Google Chrome" "chrome://extensions"

# 显示成功通知
osascript -e 'display notification "OCR服务器已启动" with title "Safari OCR Clone"'

# 保持脚本运行
wait 