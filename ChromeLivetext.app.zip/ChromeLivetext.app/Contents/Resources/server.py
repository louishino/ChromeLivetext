from flask import Flask, request, jsonify
from flask_cors import CORS
import base64
import io
from PIL import Image
import logging
import Vision
import Quartz
import objc
import Foundation
import traceback

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler('server.log')
    ]
)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app, resources={
    r"/*": {
        "origins": "*",
        "allow_headers": ["Content-Type"],
        "expose_headers": ["Content-Type"]
    }
})

def perform_ocr(image):
    try:
        # 创建Vision请求
        request = Vision.VNRecognizeTextRequest.alloc().init()
        request.setRecognitionLevel_(Vision.VNRequestTextRecognitionLevelAccurate)
        
        # 转换PIL图像为CGImage
        image_bytes = io.BytesIO()
        image.save(image_bytes, format='PNG')
        data = Foundation.NSData.alloc().initWithBytes_length_(image_bytes.getvalue(), len(image_bytes.getvalue()))
        image_source = Quartz.CGImageSourceCreateWithData(data, None)
        cgimage = Quartz.CGImageSourceCreateImageAtIndex(image_source, 0, None)
        
        # 创建处理请求的处理器
        handler = Vision.VNImageRequestHandler.alloc().initWithCGImage_options_(cgimage, None)
        
        # 执行请求
        success = handler.performRequests_error_([request], None)
        if not success:
            logger.error("OCR处理失败")
            return []
        
        results = []
        observations = request.results()
        
        if observations:
            for observation in observations:
                bbox = observation.boundingBox()
                text = observation.text()
                confidence = observation.confidence()
                
                results.append({
                    'text': text,
                    'confidence': confidence,
                    'bbox': [bbox.origin.x, bbox.origin.y, bbox.size.width, bbox.size.height]
                })
                logger.info(f"识别文本: {text} (置信度: {confidence})")
        
        return results
    except Exception as e:
        logger.error(f"OCR处理错误: {str(e)}\n{traceback.format_exc()}")
        raise

@app.route('/')
def home():
    return 'OCR Server is running!'

@app.route('/ocr', methods=['POST', 'OPTIONS'])
def ocr():
    if request.method == 'OPTIONS':
        return '', 200
        
    try:
        data = request.json
        if not data or 'image' not in data:
            logger.error("没有收到图片数据")
            return jsonify({'success': False, 'error': '没有收到图片数据'}), 400

        # 解码base64图片
        try:
            image_data = data['image']
            if 'base64,' in image_data:
                image_data = image_data.split('base64,')[1]
            image_bytes = base64.b64decode(image_data)
            image = Image.open(io.BytesIO(image_bytes))
            logger.info("成功解码图片")
        except Exception as e:
            logger.error(f"图片解码错误: {str(e)}\n{traceback.format_exc()}")
            return jsonify({'success': False, 'error': '图片解码失败'}), 400

        # 执行OCR
        try:
            results = perform_ocr(image)
            annotations = []
            for result in results:
                text = result['text']
                confidence = result['confidence']
                bbox = result['bbox']
                annotations.append([text, confidence, bbox])
            logger.info(f"OCR完成，识别到{len(annotations)}个文本区域")
            return jsonify({'success': True, 'annotations': annotations})
        except Exception as e:
            logger.error(f"OCR处理错误: {str(e)}\n{traceback.format_exc()}")
            return jsonify({'success': False, 'error': 'OCR处理失败'}), 500

    except Exception as e:
        logger.error(f"服务器错误: {str(e)}\n{traceback.format_exc()}")
        return jsonify({'success': False, 'error': str(e)}), 500

if __name__ == '__main__':
    logger.info("启动OCR服务器...")
    app.run(host='0.0.0.0', port=5001, debug=True) 